python -u word_analogy.py --vector skipgram.100d --analogy ./Data/analogy.txt
# or 
python -u word_analogy.py --vector skipgram.100d 


# find_wordAnalogy
python -u find_wordAnalogy.py -- vector skipgram.100d 

